package com.scheulder.agency.service;// AppointmentService.java
import com.scheulder.agency.dao.BookingRepository;
import com.scheulder.agency.dao.OperatorRepository;
import com.scheulder.agency.exception.BookingNotFoundException;
import com.scheulder.agency.model.Booking;
import com.scheulder.agency.util.Utility;
import jdk.jshell.execution.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private OperatorRepository operatorRepository;

    public Booking bookAppointment(Long operatorId, int startTime, int endTime) {
        // check the slot availability
        List<Booking> bookedAppointments = getBookedAppointmentsForOperator(operatorId);
        boolean isSlotAvailable = true;
        for (Booking booking : bookedAppointments) {
            if (booking.getStartTime() < endTime && booking.getEndTime() > startTime) {
                isSlotAvailable = false;
                break;
            }
        }

        //create the booking
        if (isSlotAvailable) {
            Booking newAppointment = new Booking();
            newAppointment.setOperatorId(operatorId);
            newAppointment.setStartTime(startTime);
            newAppointment.setEndTime(endTime);
            return bookingRepository.save(newAppointment);
        } else {
            //when slot not available
            throw new IllegalArgumentException("Time slot is not available");
        }
    }

    public String rescheduleBooking(Long bookingId, int newStartTime, int newEndTime) {
        // fectch existing booking
        Booking existingBooking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Appointment not found with id: " + bookingId));

        // check the slot availability
        Long operatorId = existingBooking.getOperatorId();
        List<Booking> bookedAppointments = getBookedAppointmentsForOperator(operatorId);
        boolean isSlotAvailable = Utility.checkIfSlotAvailable(bookingId, bookedAppointments, newStartTime, newEndTime);
        //update the slot
        if (isSlotAvailable) {
            existingBooking.setStartTime(newStartTime);
            existingBooking.setEndTime(newEndTime);
            bookingRepository.save(existingBooking);
        } else {
            throw new IllegalArgumentException("New time slot is not available");
        }
        return "Booking rescheduled Successfully!";
    }

    public String cancelBooking(Long appointmentId) {
        // Fetch the existing Booking
        Booking existingBooking = bookingRepository.findById(appointmentId)
                .orElseThrow(() -> new BookingNotFoundException("Appointment not found with id: " + appointmentId));
        // Remove the Booking from the repository
        bookingRepository.delete(existingBooking);
        return "Booking cancelled successfully!";
    }

    public List<Booking> getBookedAppointmentsForOperator(Long operatorId) {
        return bookingRepository.findByOperatorId(operatorId);
    }

    public List<List<Integer>> getOpenSlotsForOperator(Long operatorId) {
        List<Booking> bookedAppointments = getBookedAppointmentsForOperator(operatorId);
        List<List<Integer>> openSlots = new ArrayList<>();

        boolean[] slots = new boolean[24]; // Represent 24 hours of the day
        Arrays.fill(slots, true); // Initially, all slots are open

        for (Booking appointment : bookedAppointments) {
            for (int hour = appointment.getStartTime(); hour < appointment.getEndTime(); hour++) {
                slots[hour] = false;
            }
        }

        int start = -1;
        for (int hour = 0; hour < 24; hour++) {
            if (slots[hour]) {
                if (start == -1) {
                    start = hour;
                }
            } else {
                if (start != -1) {
                    openSlots.add(Arrays.asList(start, hour));
                    start = -1;
                }
            }
        }

        // Handle the case where the last slot is open
        if (start != -1) {
            openSlots.add(Arrays.asList(start, 24));
        }

        return openSlots;
    }
}