package com.scheulder.agency.controller;

import com.scheulder.agency.exception.BookingNotFoundException;
import com.scheulder.agency.model.Booking;
import com.scheulder.agency.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/bookings")
public class BookingController {
    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<Object> bookBooking(
            @RequestParam(required = false) Long operatorId,
            @RequestParam int startTime,
            @RequestParam int endTime
    ) {
        try {
            Booking booking = bookingService.bookAppointment(operatorId, startTime, endTime);
            return new ResponseEntity<>(booking, HttpStatus.CREATED);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> rescheduleBooking(
            @PathVariable Long id,
            @RequestParam int newStartTime,
            @RequestParam int newEndTime
    ) {
        try {
            String response = bookingService.rescheduleBooking(id, newStartTime, newEndTime);
            return new ResponseEntity<String>(response, HttpStatus.OK);
        } catch (BookingNotFoundException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelBooking(@PathVariable Long id) {
        try {
            String response = bookingService.cancelBooking(id);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (BookingNotFoundException ex) {
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/operator/{operatorId}")
    public ResponseEntity<List<Booking>> getBookedBookingsForOperator(@PathVariable Long operatorId) {
        List<Booking> bookings = bookingService.getBookedAppointmentsForOperator(operatorId);
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    @GetMapping("/openSlots/operator/{operatorId}")
    public ResponseEntity<List<List<Integer>>> getOpenSlotsForOperator(@PathVariable Long operatorId) {
        List<List<Integer>> openSlots = bookingService.getOpenSlotsForOperator(operatorId);
        return new ResponseEntity<>(openSlots, HttpStatus.OK);
    }
}