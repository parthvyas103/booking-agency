package com.scheulder.agency.util;

import com.scheulder.agency.model.Booking;

import java.util.List;

public class Utility {

    public static boolean checkIfSlotAvailable(Long bookingId, List<Booking> bookedAppointments, int newStartTime, int newEndTime ){
        boolean isSlotAvailable = true;
        for (Booking booking : bookedAppointments) {
            if (booking.getId() != bookingId && booking.getStartTime() < newEndTime && booking.getEndTime() > newStartTime) {
                return false;
            }
        }
        return true;
    }
}
