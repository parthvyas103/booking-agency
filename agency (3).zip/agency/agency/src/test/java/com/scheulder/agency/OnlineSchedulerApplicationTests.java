package com.scheulder.agency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
